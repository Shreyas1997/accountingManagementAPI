const mocha = require('mocha');
const mongoose = require('mongoose');
const Users = require('../api/models/users');
const SalesInvoice = require('../api/models/salesModel');
const PurchaseInvoice = require('../api/models/purchaseModel');
const assert = require('assert');

describe('Updating User', () => {
    let updater;
    beforeEach((done) => {
        updater = Users({
            _id: new mongoose.Types.ObjectId(),
            name: "Jhonn Doe",
            email: "jhonn@gmail.com",
            password: "#HelloJhonD",
            gender: "Male",
            position: "Graphic Designer",
            phone: "7798653201"
        });

        updater.save()
        .then(() => {
            assert(updater.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
    it('Updating user account in DB', (done) => {
        updater.set("password", "#HelloJhon2019");
        updater.save()
        .then((result) => {
            Users.findOne({})
            console.log("Updated User password.");
            console.log(result);
            assert((result.position !== "#HelloJhonD"));
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });

    let salesupdater;
    beforeEach((done) => {
        salesupdater = SalesInvoice({
            customer: [
                {
                    customerName: "Rakesh",
                    address: "Delhi",
                    gstNo: "596489645526611",
                    placeOfSupplyOfService: "Mumbai"
                }
            ],
            invoice:[
                {
                    invoiceDate: "23/11/2019"
                }
            ],
            billingOffice: [
                {
                    address: "Mumbai",
                    salesPerson: "Rohit"
                }
            ],
            product: [
                {
                    productName: "Monitor",
                    quantity: 50,
                    pricePerPiece: 2000,
                    TotalPrice: 100000
                }
            ],
            subscription: [
                {
                    startDate: "19/11/2019",
                    endDate: "25/11/2019"
                }
            ],
            amount: 100000
        });

        salesupdater.save()
        .then(() => {
            assert(salesupdater.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
    it('Updating Sales invoice in DB', (done) => {
        salesupdater.set("amount", "300000");
        salesupdater.save()
        .then((result) => {
            Users.findOne({})
            console.log("Updated Sales invoice.");
            console.log(result);
            assert(result.amount !== 100000);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });


    let purchaseupdater;
    beforeEach((done) => {
        purchaseupdater = PurchaseInvoice({
            companyName: "BML Pvt. Ltd.",
            invoice: [
                {
                    invoiceDate: "23/11/2019"
                }
            ],
            transactionId: [
                {

                }
            ],
            phone: "7796867726",
            address: "Mumbai",
            dealerName: "Royal Oak",
            items: [
                {
                    itemName: "Wooden Chairs",
                    quantity: 20,
                    pricePerPiece: 500,
                    TotalPrice: 10000
                }
            ],
            issuedBy: "Rajesh"
        });

        purchaseupdater.save()
        .then(() => {
            assert(purchaseupdater.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
    it('Updating Purchase invoice in DB', (done) => {
        purchaseupdater.set("issuedBy", "Suresh");
        purchaseupdater.save()
        .then((result) => {
            Users.findOne({})
            console.log("Updated Purchase invoice.");
            console.log(result);
            assert(result.amount !== 100000);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
});