const mocha = require('mocha');
const mongoose = require('mongoose');
const Users = require('../api/models/users');
const SalesInvoice = require('../api/models/salesModel');
const PurchaseInvoice = require('../api/models/purchaseModel');
const PnLStatement = require('../api/models/pnlModel');
const assert = require('assert');

describe('Reading contents from DB using PUT method', () => {
    /*let reader;
    beforeEach((done) => {
        reader = Users({
            _id: new mongoose.Types.ObjectId(),
            name: "Jhonn Doe",
            email: "jhonn@gmail.com",
            password: "#HelloJhonD",
            gender: "Male",
            position: "Graphic Designer",
            phone: "7798653201"
        });

        reader.save()
        .then(() => {
            assert(reader.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
    it('Reading user account in DB', (done) => {
        Users.find({
            name: "Jhonn Doe",
            email: "jhonn@gmail.com",
            password: "#HelloJhonD",
            gender: "Male",
            position: "Graphic Designer",
            phone: "7798653201"
        })
        .then((result) => {
            console.log("User account from DB.");
            console.log(result);
            assert(reader._id.toString() == result[0]._id.toString());
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });*/


    let salesReader;
    beforeEach((done) => {
        salesReader = SalesInvoice({
            customer: [
                {
                    customerName: "Rakesh",
                    address: "Delhi",
                    gstNo: "596489645526611",
                    placeOfSupplyOfService: "Mumbai"
                }
            ],
            invoice:[
                {
                    invoiceDate: "23/11/2019"
                }
            ],
            billingOffice: [
                {
                    address: "Mumbai",
                    salesPerson: "Rohit"
                }
            ],
            product: [
                {
                    productName: "Monitor",
                    quantity: 50,
                    pricePerPiece: 2000,
                    TotalPrice: 100000
                }
            ],
            subscription: [
                {
                    startDate: "19/11/2019",
                    endDate: "25/11/2019"
                }
            ],
            amount: 100000
        });

        salesReader.save()
        .then(() => {
            assert(salesReader.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
    it('Reading sales invoice in DB', (done) => {
        SalesInvoice.findOne({})
        .then((result) => {
            console.log("Sales invoice from DB.");
            console.log(result);
            assert(result._id.toString() === salesReader._id.toString() );
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });



    let purchaseReader;
    beforeEach((done) => {
        purchaseReader = PurchaseInvoice({
            companyName: "BML Pvt. Ltd.",
            invoice: [
                {
                    invoiceDate: "23/11/2019"
                }
            ],
            transactionId: [
                {

                }
            ],
            phone: "7796867726",
            address: "Mumbai",
            dealerName: "Royal Oak",
            items: [
                {
                    itemName: "Wooden Chairs",
                    quantity: 20,
                    pricePerPiece: 500,
                    TotalPrice: 10000
                }
            ],
            issuedBy: "Rajesh"
        });

        purchaseReader.save()
        .then(() => {
            assert(purchaseReader.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
    it('Reading purchase invoice in DB', (done) => {
        PurchaseInvoice.findOne({})
        .then((result) => {
            console.log("Purchase invoice from DB.");
            console.log(result);
            assert(result._id.toString() === purchaseReader._id.toString());
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });




    let pnlReader;
    beforeEach((done) => {
        pnlReader = PnLStatement({
            company: "BML Pvt. Ltd.",
            date: "23/11/2019",
            period: "2018-2019",
            product: [
                {
                    productName: "Monitor",
                    price: 2000
                }
            ],
            totatIncome: 2000,
            discountCosts: 10,
            gross: 1990,
            companyExpenses: [
                {
                    operating: 20,
                    marketing: 50,
                    employee: 50,
                    legal: 30,
                    continuingEd: 10
                }
            ],
            totalExpenses: 160,
            netIncome: 1830,
            verdict: "Profit"
        });

        pnlReader.save()
        .then(() => {
            assert(pnlReader.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
    it('Reading PnL Statements in DB', (done) => {
        PnLStatement.findOne({})
        .then((result) => {
            console.log("PnL Statements from DB.");
            console.log(result);
            assert(result._id.toString() === pnlReader._id.toString());
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
});