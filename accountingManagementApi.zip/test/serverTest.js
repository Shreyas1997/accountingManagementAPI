const mongoose = require('mongoose');

mongoose.Promise = global.Promise;

before((done) => {
    mongoose.connect('mongodb://localhost/testAccountingManagement', {useUnifiedTopology: true, useNewUrlParser: true });
    mongoose.connection.once('open', () => {
        console.log("Testing DataBase Connected.");
        done();
    })
    .on('error', () => {
        console.log('Connection Error:', error);
    });
});

beforeEach((done) => {
    mongoose.connection.collections.users.drop(() => {});
    mongoose.connection.collections.salesinvoices.drop(() => {});
    mongoose.connection.collections.purchaseinvoices.drop(() => {});
    mongoose.connection.collections.pnlstatements.drop(() => {});
    console.log('Collection Dropped.');
    done();
});