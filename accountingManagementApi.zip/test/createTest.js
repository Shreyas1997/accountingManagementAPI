const mocha = require('mocha');
const mongoose = require('mongoose');
const Users = require('../api/models/users');
const SalesInvoice = require('../api/models/salesModel');
const PurchaseInvoice = require('../api/models/purchaseModel');
const PnLStatement = require('../api/models/pnlModel');
const assert = require('assert');

describe('Populating contents into DB using POST method', () => {
    it('Creating user account in DB', (done) => {
        const users = new Users({
            _id: new mongoose.Types.ObjectId(),
            name: "Jhonn Doe",
            email: "jhonn@gmail.com",
            password: "#HelloJhonD",
            gender: "Male",
            position: "Graphic Designer",
            phone: "7798653201"
        });

        users.save()
        .then(() => {
            assert(users.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });

    it('Creating Sales Invoice in DB', (done) => {
        const sale = new SalesInvoice({
            _id: new mongoose.Types.ObjectId(),
            customer: [
                {
                    customerName: "Rakesh",
                    address: "Delhi",
                    gstNo: "596489645526611",
                    placeOfSupplyOfService: "Mumbai"
                }
            ],
            invoice:[
                {
                    invoiceDate: "23/11/2019"
                }
            ],
            billingOffice: [
                {
                    address: "Mumbai",
                    salesPerson: "Rohit"
                }
            ],
            product: [
                {
                    productName: "Monitor",
                    quantity: 50,
                    pricePerPiece: 2000,
                    TotalPrice: 100000
                }
            ],
            subscription: [
                {
                    startDate: "19/11/2019",
                    endDate: "25/11/2019"
                }
            ],
            amount: 100000
        });

        sale.save()
        .then(() => {
            assert(sale.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });

    it('Creating Purchase Invoice in DB', (done) => {
        const purchase = new PurchaseInvoice({
            _id: new mongoose.Types.ObjectId(),
            companyName: "BML Pvt. Ltd.",
            invoice: [
                {
                    invoiceDate: "23/11/2019"
                }
            ],
            transactionId: [
                {

                }
            ],
            phone: "7796867726",
            address: "Mumbai",
            dealerName: "Royal Oak",
            items: [
                {
                    itemName: "Wooden Chairs",
                    quantity: 20,
                    pricePerPiece: 500,
                    TotalPrice: 10000
                }
            ],
            issuedBy: "Rajesh"
        });

        purchase.save()
        .then(() => {
            assert(purchase.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });

    it('Creating PnLStatement in DB', (done) => {
        const pnl = new PnLStatement({
            _id: new mongoose.Types.ObjectId(),
            company: "BML Pvt. Ltd.",
            date: "23/11/2019",
            period: "2018-2019",
            product: [
                {
                    productName: "Monitor",
                    price: 2000
                }
            ],
            totatIncome: 2000,
            discountCosts: 10,
            gross: 1990,
            companyExpenses: [
                {
                    operating: 20,
                    marketing: 50,
                    employee: 50,
                    legal: 30,
                    continuingEd: 10
                }
            ],
            totalExpenses: 160,
            netIncome: 1830,
            verdict: "Profit"
        });

        pnl.save()
        .then(() => {
            assert(pnl.isNew === false);
            done();
        })
        .catch((err) => {
            console.log(err);
        });
    });
});