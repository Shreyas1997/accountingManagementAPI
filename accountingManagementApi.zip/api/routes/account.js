const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken')

const Users = require('../models/users');
const SalesInvoice = require('../models/salesModel');
const PurchaseInvoice = require('../models/purchaseModel');
const PnLStatement = require('../models/pnlModel');

/*login user*/
router.post('/login', (req, res, next) => {
    Users.find({email: req.body.email})
    .exec()
    .then(user => {
        if(user.length < 1){
            return res.status(401).json({
                message: 'Authentication Failed.'
            });
        }
        bcrypt.compare(req.body.password, user[0].password, (err, result) => {
            if(err){
                return res.status(401).json({
                    message: 'Authentication Failed.'
                }); 
            } 
            if(result){
                const token = jwt.sign({
                    email: user[0].email,
                    userId: user[0]._id
                }, "secret", 
                    {
                        expiresIn: "1h"
                    }
                );
                return res.status(200).json({
                    message: 'Authentication Successful.',
                    token: token
                });
            }
            return res.status(401).json({
                message: 'Authentication Failed.'
            });
        })
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
});

/*register user*/
router.get('/register', (req, res, next) => {
    Users.find()
    .select('_id name email gender position phone')
    .exec()
    .then(docs => {
        res.status(200).json({
            count: docs.length,
            users: docs.map(doc => {
                return {
                    _id: doc._id,
                    name: doc.name,
                    email: doc.email,
                    gender: doc.gender,
                    position: doc.position,
                    phone:doc.phone,
                    request: {
                        type: 'GET',
                        url: 'http://localhost:3000/register/' + doc._id
                    }
                }
            })
        });
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

router.post('/register', (req, res, next) => {
    Users.find({email: req.body.email})
        .exec()
        .then(user => {
            if(user.length >=1){
                return res.status(409).json({
                    message: 'Mail exists.'
                });
            } else{
                bcrypt.hash(req.body.password, 10, (err, hash) => {
                    if(err){
                        res.status(500).json({
                            error: err
                        });
                    } else{
                        const userRegister = new Users({
                            _id: new mongoose.Types.ObjectId(),
                            name: req.body.name,
                            email: req.body.email,
                            password: hash,
                            gender: req.body.gender,
                            position: req.body.position,
                            phone: req.body.phone
                        });
                        userRegister.save()
                        .then(result => {
                            console.log(result);
                            res.status(201).json({
                                message: 'User Created',
                                registeredUser: userRegister
                            });
                        })
                        .catch(err => {
                            console.log(err);
                            res.status(500).json({
                                error: err
                            });
                        });
                    }
                })
            }
        });    
});

/*Edit Profile*/
router.get('/editProfile/:userId', (req, res, next) => {
    const id = req.params.userId;
    Users.findById(id)
    .select('_id name email gender position phone')
    .exec()
    .then(docs => {
        console.log(docs);
        res.status(200).json(docs);
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

router.put('/editProfile/:userId', (req, res, next) => {
    const id = req.params.userId;
    const updateOps = {};
    for(const ops of req.body){
        updateOps[ops.propName] = ops.value;
    }
    Users.update({_id: id}, { $set: updateOps })
    .exec()
    .then(result => {
        console.log(result);
        res.status(200).json(result);
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
});

/*Change Password*/
router.get('/changePassword/:passwordId', (req, res, next) => {
    const id = req.params.passwordId;
    Users.findById(id)
    .select('_id name email password gender position phone')
    .exec()
    .then(docs => {
        console.log(docs);
        res.status(200).json(docs);
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

router.put('/changePassword/:passwordId', (req, res, next) => {
    const id = req.params.passwordId;
    bcrypt.hash(req.body.password, 10, (err, hash) => {
        if(err){
            res.status(500).json({
                error: err
            });
        } else{
            Users.update({_id: id}, { $set: {password: hash} })
            .exec()
            .then(result => {
                console.log(result);
                res.status(200).json({
                    message: "Password updated."
                });
            })
            .catch(err => {
                console.log(err);
                res.status(500).json({
                    error: err
                });
            });
        }
    });
});

/*Purchase Invoice*/
router.get('/purchaseInvoice', (req, res, next) => {
    PurchaseInvoice.find()
    .exec()
    .then(docs => {
        res.status(200).json({
            count: docs.length,
            PurchaseInvoices: docs
        });
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

router.get('/purchaseInvoice/:purchaseInvoiceId', (req, res, next) => {
    const id = req.params.purchaseInvoiceId;
    PurchaseInvoice.findById(id)
    .exec()
    .then(docs => {
        res.status(200).json({
            PurchaseInvoicesID: docs._id,
            Content: docs
        });
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

router.post('/purchaseInvoice', (req, res, next) => {
    const purchaseInvoice = new PurchaseInvoice(req.body);
    purchaseInvoice.save()
    .then(result => {
        console.log(result);
        res.status(201).json(result);
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
});

router.put('/purchaseInvoice/:purchaseInvoiceID', (req, res, next) => {
    const id = req.params.purchaseInvoiceID;
    const updateOps = {};
    for(const props of req.body){
        updateOps[props.propName] = props.value;
    }
    PurchaseInvoice.update({_id: id}, { $set: updateOps })
    .exec()
    .then(result => {
        console.log(result);
        res.status(200).json(result);
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
});

/*Sales Invoice*/
router.get('/salesInvoice', (req, res, next) => {
    SalesInvoice.find()
    .exec()
    .then(docs => {
        res.status(200).json({
            count: docs.length,
            SalesInvoices: docs
        });
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

router.get('/salesInvoice/:salesInvoiceID', (req, res, next) => {
    const id = req.params.salesInvoiceID;
    SalesInvoice.findById(id)
    .exec()
    .then(docs => {
        res.status(200).json({
            count: docs.length,
            SalesInvoices: docs
        });
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

router.post('/salesInvoice', (req, res, next) => {
    const salesInvoice = new SalesInvoice(req.body);
    salesInvoice.save()
    .then(result => {
        console.log(result);
        res.status(201).json(result);
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
});

router.put('/salesInvoice/:salesInvoiceID', (req, res, next) => {
    const id = req.params.salesInvoiceID;
    const updateOps = {};
    for(const props of req.body){
        updateOps[props.propName] = props.value;
    }
    SalesInvoice.update({_id: id}, { $set: updateOps })
    .exec()
    .then(result => {
        console.log(result);
        res.status(200).json(result);
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
});

/*PnLStatement*/
router.get('/PnLStatement', (req, res, next) => {
    PnLStatement.find()
    .exec()
    .then(docs => {
        res.status(200).json({
            count: docs.length,
            PnLs: docs
        });
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

router.get('/PnLStatement/:PnLId', (req, res, next) => {
    const id = req.params.PnLId;
    PnLStatement.findById(id)
    .exec()
    .then(docs => {
        console.log(docs);
        res.status(200).json({
            PnLID: docs._id,
            content: docs
        });
    })
    .catch(err => {
        res.status(500).json({
            error: err
        });
    });
});

router.post('/PnLStatement', (req, res, next) => {
    const pnlStatement = new PnLStatement(req.body);
    pnlStatement.save()
    .then(result => {
        console.log(result);
        res.status(201).json({
            message: 'Statement Created',
            Statement: pnlStatement
        });
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
});


module.exports = router;