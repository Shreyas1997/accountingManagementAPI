const mongoose = require('mongoose');

/*PnLStatement Model*/
const product = mongoose.Schema({
    productName: {type: String, required: true},
    price: {type: Number, required: true}
});

const expenseArray = mongoose.Schema({
    operating: {type: Number, required: true},
    marketing: {type: Number, required: true},
    employee: {type: Number, required: true},
    legal: {type: Number, required: true},
    continuingEd: {type: Number, required: true}
});

const pNLSchema = mongoose.Schema({
    company: {type: String, required: true},
    date: {type: String, required: true},
    period: {type: String, required: true},
    product: [product],
    totatIncome: {type: Number, required: true},
    discountCosts: {type: Number, required: true},
    gross: {type: Number, required: true},
    companyExpenses: [expenseArray],
    totalExpenses: {type: Number, required: true},
    netIncome: {type: Number, required: true},
    verdict: {type: String, required: true}
});

const PnLStatement = mongoose.model('PnLStatement', pNLSchema);

module.exports = PnLStatement;