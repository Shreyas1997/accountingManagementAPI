const mongoose = require('mongoose');

/*Sales Invoice Model*/
const customerSchema = mongoose.Schema({
    customerName: {type: String, required: true},
    address: {type: String, required: true},
    gstNo: {type: String, required: true},
    placeOfSupplyOfService: {type: String, required: true}
});

const invoiceSchema = mongoose.Schema({
    invoiceDate: {type: String, required: true}
});

const billingSchema = mongoose.Schema({
    address: {type: String, required: true},
    salesPerson: {type: String, required: true}
});

const productsSchema = mongoose.Schema({
    productName: {type: String, required: true},
    quantity: {type: Number, required: true},
    pricePerPiece: {type: Number, required: true},
    TotalPrice: {type: Number, required: true}
});

const subscriptionSchema = mongoose.Schema({
    startDate: {type: String, required: true},
    endDate: {type: String, required: true}
});

const salesSchema = mongoose.Schema({
    customer: [customerSchema],
    invoice:[invoiceSchema],
    billingOffice: [billingSchema],
    product: [productsSchema],
    subscription: [subscriptionSchema],
    amount: {type: Number, required: true}
});

const SalesInvoice = mongoose.model('SalesInvoice', salesSchema);

module.exports = SalesInvoice;