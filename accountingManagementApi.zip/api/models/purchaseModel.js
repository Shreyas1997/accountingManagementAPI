const mongoose = require('mongoose');


/*Purchase Invoice Model*/
const item = mongoose.Schema({
    itemName: {type: String, required: true},
    quantity: {type: Number, required: true},
    pricePerPiece: {type: Number, required: true},
    TotalPrice: {type: Number, required: true}
});

const invoiceSchema = mongoose.Schema({
    invoiceDate: {type: String, required: true}
});

const transactionSchema = mongoose.Schema({
    
});

const purchaseSchema = mongoose.Schema({
    companyName: {type: String, required: true},
    invoice: [invoiceSchema],
    transactionId: [transactionSchema],
    phone: {type: String, required: true},
    address: {type: String, required: true},
    dealerName: {type: String, required: true},
    items: [item],
    issuedBy: {type: String, required: true}
});

const PurchaseInvoice = mongoose.model('PurchaseInvoice', purchaseSchema);

module.exports = PurchaseInvoice;